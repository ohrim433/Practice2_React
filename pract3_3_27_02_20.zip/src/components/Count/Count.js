import React from 'react';

function Count({count}) {
    return (
        <div>
            <h2>{count}</h2>
        </div>
    );
}

export default Count;